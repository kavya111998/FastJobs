class UpgradePlan {
    elements = {
        // Upgrade plan elements
    }
}