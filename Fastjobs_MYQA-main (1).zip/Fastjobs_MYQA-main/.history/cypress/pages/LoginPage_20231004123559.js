class LoginPage {
    elements = {
        // login elements
    }

    loginEmployer = (username, passowrd) => {
        // steps to login
    }
}

module.exports = new LoginPage();