describe('Login', () => {
    beforeEach(() => {
        cy.visit("/login")
    })
})